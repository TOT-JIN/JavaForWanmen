//Java Platform, Enterprise Edition (Java EE) 
//Servlet ?
//a request-response programming model.

//1. extends javax.servlet.http.HttpServlet
//2. @WebServlet(urlPatterns = "/home.do")
//3. doGet(HttpServletRequest request, HttpServletResponse response)
//4. response?

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = "/home.do")
public class HomeServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		//response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter(); // ISO8859-1
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Data Application Lab!!!!!!!!</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("My First Servlet ����");
		out.println("</body>");
		out.println("</html>");
	}

}